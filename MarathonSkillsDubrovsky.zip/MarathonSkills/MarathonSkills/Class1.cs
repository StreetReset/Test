using System;

namespace MarathonSkills
{
    public class Class1
    {
    }
}
